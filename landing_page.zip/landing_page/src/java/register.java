import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class register extends HttpServlet {
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
PrintWriter out= response.getWriter();
try {
String email_id=request.getParameter("email");
String password=request.getParameter("password");
Class.forName("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/software_testing","root","");
PreparedStatement pst = con.prepareStatement("INSERT INTO register(`Email ID`, `password`) VALUES (?,?)");

pst.setString(1,email_id);
pst.setString(2,password);
int data= pst.executeUpdate();
if(data>0){
response.sendRedirect("index.html");
}else{
out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!");
}
}catch (Exception e){out.println(e);}

}
}